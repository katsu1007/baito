import SwiftUI
import WebKit
import UIKit
import EventKit

@main
struct BaitoApp: App {
    var body: some Scene {
        WindowGroup {
            WebView()
                .ignoresSafeArea()
        }
    }
}

/// 入力したバイトの記録をこの携帯の中に保存する
final class Store: NSObject, WKScriptMessageHandler {
    static let key = "baito-state"
    func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
        if let json = message.body as? String {
            UserDefaults.standard.set(json, forKey: Store.key)
        }
    }
}

/// CSVをファイルにして、共有メニュー（ファイルに保存・LINE・AirDropなど）を出す
final class Sharer: NSObject, WKScriptMessageHandler {
    func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let dict = message.body as? [String: Any],
              let name = dict["name"] as? String,
              let text = dict["text"] as? String else { return }
        let safeName = name.replacingOccurrences(of: "/", with: "_")
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(safeName)
        do {
            try text.write(to: url, atomically: true, encoding: .utf8)
        } catch {
            return
        }
        DispatchQueue.main.async {
            presentShareSheet(for: url)
        }
    }
}

/// 共有メニューを出す（CSV・PDF共通）
func presentShareSheet(for url: URL) {
    let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
    guard let window = scenes.flatMap({ $0.windows }).first(where: { $0.isKeyWindow }) ?? scenes.first?.windows.first,
          var top = window.rootViewController else { return }
    while let presented = top.presentedViewController { top = presented }
    let sheet = UIActivityViewController(activityItems: [url], applicationActivities: nil)
    sheet.popoverPresentationController?.sourceView = top.view
    top.present(sheet, animated: true)
}

/// 印刷用のページからA4のPDFを作って、共有メニュー（ファイルに保存・プリント・LINEなど）を出す
final class PDFMaker: NSObject, WKScriptMessageHandler {
    func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let dict = message.body as? [String: Any],
              let name = dict["name"] as? String,
              let html = dict["html"] as? String else { return }
        DispatchQueue.main.async {
            let formatter = UIMarkupTextPrintFormatter(markupText: html)
            let renderer = UIPrintPageRenderer()
            renderer.addPrintFormatter(formatter, startingAtPageAt: 0)
            let paper = CGRect(x: 0, y: 0, width: 595.2, height: 841.8)   // A4
            let printable = paper.insetBy(dx: 36, dy: 40)
            renderer.setValue(NSValue(cgRect: paper), forKey: "paperRect")
            renderer.setValue(NSValue(cgRect: printable), forKey: "printableRect")

            let data = NSMutableData()
            UIGraphicsBeginPDFContextToData(data, paper, nil)
            let pages = max(renderer.numberOfPages, 1)
            renderer.prepare(forDrawingPages: NSRange(location: 0, length: pages))
            for i in 0..<pages {
                UIGraphicsBeginPDFPage()
                renderer.drawPage(at: i, in: UIGraphicsGetPDFContextBounds())
            }
            UIGraphicsEndPDFContext()

            let safeName = name.replacingOccurrences(of: "/", with: "_")
            let url = FileManager.default.temporaryDirectory.appendingPathComponent(safeName)
            do {
                try data.write(to: url, options: .atomic)
            } catch {
                return
            }
            presentShareSheet(for: url)
        }
    }
}

/// iPhoneのカレンダーの「バイト」カレンダーとやり取りする
final class CalendarBridge: NSObject, WKScriptMessageHandler {
    let eventStore = EKEventStore()

    private lazy var formatter: DateFormatter = {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.calendar = Calendar(identifier: .gregorian)
        f.timeZone = TimeZone.current
        f.dateFormat = "yyyy-MM-dd HH:mm"
        return f
    }()
    private lazy var dayFormatter: DateFormatter = {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.calendar = Calendar(identifier: .gregorian)
        f.timeZone = TimeZone.current
        f.dateFormat = "yyyy-MM-dd"
        return f
    }()

    func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let dict = message.body as? [String: Any],
              let op = dict["op"] as? String,
              let rid = dict["rid"] as? Int else { return }
        weak var webView = message.webView

        func reply(_ object: [String: Any]) {
            let data = (try? JSONSerialization.data(withJSONObject: object)) ?? Data("{}".utf8)
            let json = String(data: data, encoding: .utf8) ?? "{}"
            DispatchQueue.main.async {
                webView?.evaluateJavaScript("window.__calCb && window.__calCb(\(rid), \(json))", completionHandler: nil)
            }
        }

        requestAccess { granted in
            guard granted else { reply(["error": "denied"]); return }
            guard let calendar = self.baitoCalendar() else { reply(["error": "nocal"]); return }

            switch op {
            case "list":
                guard let fromText = dict["from"] as? String, let toText = dict["to"] as? String,
                      let from = self.dayFormatter.date(from: fromText),
                      let to = self.dayFormatter.date(from: toText) else { reply(["error": "args"]); return }
                let end = to.addingTimeInterval(24 * 60 * 60)
                let predicate = self.eventStore.predicateForEvents(withStart: from, end: end, calendars: [calendar])
                let events = self.eventStore.events(matching: predicate).filter { !$0.isAllDay }
                let list: [[String: Any]] = events.map { event in
                    [
                        "id": event.eventIdentifier ?? "",
                        "start": self.formatter.string(from: event.startDate),
                        "end": self.formatter.string(from: event.endDate),
                        "location": event.location ?? "",
                    ]
                }
                reply(["events": list])

            case "save":
                guard let startText = dict["start"] as? String, let endText = dict["end"] as? String,
                      let start = self.formatter.date(from: startText),
                      let end = self.formatter.date(from: endText) else { reply(["error": "args"]); return }
                var event: EKEvent? = nil
                if let id = dict["id"] as? String, !id.isEmpty {
                    event = self.eventStore.event(withIdentifier: id)
                }
                let target = event ?? EKEvent(eventStore: self.eventStore)
                target.calendar = calendar
                target.title = (dict["title"] as? String) ?? "バイト"
                target.notes = dict["notes"] as? String
                if let place = dict["location"] as? String { target.location = place.isEmpty ? nil : place }
                target.startDate = start
                target.endDate = end
                do {
                    try self.eventStore.save(target, span: .thisEvent, commit: true)
                    reply(["id": target.eventIdentifier ?? ""])
                } catch {
                    reply(["error": "save"])
                }

            case "delete":
                if let id = dict["id"] as? String, let event = self.eventStore.event(withIdentifier: id) {
                    try? self.eventStore.remove(event, span: .thisEvent, commit: true)
                }
                reply(["ok": true])

            default:
                reply(["error": "op"])
            }
        }
    }

    private func requestAccess(_ done: @escaping (Bool) -> Void) {
        if #available(iOS 17.0, *) {
            eventStore.requestFullAccessToEvents { granted, _ in done(granted) }
        } else {
            eventStore.requestAccess(to: .event) { granted, _ in done(granted) }
        }
    }

    /// 「バイト」カレンダーを探す。無ければ作る
    private func baitoCalendar() -> EKCalendar? {
        if let found = eventStore.calendars(for: .event).first(where: { $0.title == "バイト" && $0.allowsContentModifications }) {
            return found
        }
        let calendar = EKCalendar(for: .event, eventStore: eventStore)
        calendar.title = "バイト"
        calendar.cgColor = UIColor.systemOrange.cgColor
        var candidates: [EKSource] = []
        if let source = eventStore.defaultCalendarForNewEvents?.source { candidates.append(source) }
        candidates.append(contentsOf: eventStore.sources.filter { $0.sourceType == .calDAV || $0.sourceType == .local })
        for source in candidates {
            calendar.source = source
            if (try? eventStore.saveCalendar(calendar, commit: true)) != nil {
                return calendar
            }
        }
        return nil
    }
}

/// ネットのリンクはアプリの外（Safari）で開く
final class LinkOpener: NSObject, WKNavigationDelegate, WKUIDelegate {
    var observers: [NSObjectProtocol] = []
    deinit { observers.forEach { NotificationCenter.default.removeObserver($0) } }
    private func openOutside(_ url: URL?) -> Bool {
        guard let url = url, let scheme = url.scheme?.lowercased(), scheme == "http" || scheme == "https" else { return false }
        UIApplication.shared.open(url)
        return true
    }
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if openOutside(navigationAction.request.url) { decisionHandler(.cancel) } else { decisionHandler(.allow) }
    }
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        _ = openOutside(navigationAction.request.url)
        return nil
    }
}

struct WebView: UIViewRepresentable {
    let store = Store()
    let sharer = Sharer()
    let pdfMaker = PDFMaker()
    let calendarBridge = CalendarBridge()
    // リンク係はSwiftUIに持っておいてもらう（弱い参照で消えないように）
    func makeCoordinator() -> LinkOpener { LinkOpener() }

    func makeUIView(context: Context) -> WKWebView {
        let controller = WKUserContentController()
        controller.add(store, name: "store")
        controller.add(sharer, name: "share")
        controller.add(pdfMaker, name: "pdf")
        controller.add(calendarBridge, name: "cal")

        // 前回の内容をページが読み込まれる前に渡す
        let saved = UserDefaults.standard.string(forKey: Store.key) ?? "null"
        let script = WKUserScript(source: "window.__nativeState = \(saved);",
                                  injectionTime: .atDocumentStart,
                                  forMainFrameOnly: true)
        controller.addUserScript(script)

        let config = WKWebViewConfiguration()
        config.userContentController = controller

        let webView = WKWebView(frame: .zero, configuration: config)
        webView.isOpaque = false
        webView.backgroundColor = .systemBackground
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator

        // アプリに戻ってきた時に、カレンダーとの同期をページに頼む
        let token = NotificationCenter.default.addObserver(forName: UIApplication.willEnterForegroundNotification,
                                                           object: nil, queue: .main) { [weak webView] _ in
            webView?.evaluateJavaScript("window.__onForeground && window.__onForeground()", completionHandler: nil)
        }
        context.coordinator.observers.append(token)

        if let url = Bundle.main.url(forResource: "index", withExtension: "html") {
            webView.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
        }
        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}
}
